﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace profesores
{
    internal class Profesores
    {

        string[] Nombres;
        int[] Edad;
        int[] Genero;
        int[] Maestria;
        public Profesores()
        {
            IngDatos();
            Console.ReadKey();
            Console.Clear();
            ImprimirArreglos();
            PromEdad();
            Console.ReadKey();
            Console.Clear();
            MenoryMayor();
            Console.ReadKey();
            Console.Clear();
            HombresyMujeres();
            Console.ReadKey();
            Console.Clear();
            Maestrias();

        }

        public void IngDatos()
        {
            string nombreV;
            int edadV;
            int generoV;
            int maestriaV;
            int resp;
            Console.WriteLine("Cuantos maestros deseas introducir? ");
            resp = int.Parse(Console.ReadLine());

            Nombres = new string[resp];
            Edad = new int[resp];
            Genero = new int[resp];
            Maestria = new int[resp];   

            for (int i = 0; i < Nombres.Length; i++)
            {

                Console.WriteLine("Ingresa el nombre del "+ (i +1) +" maestr@: ");
                nombreV = Console.ReadLine();
                Nombres[i] = nombreV;

                Console.WriteLine("Introduce la edad del: " + (i + 1) + " maestr@");
                edadV = int.Parse(Console.ReadLine());
                Edad[i] = edadV;

                Console.WriteLine("Introduce el genero del maestr@: 1.Hombre 2.Mujer");
                generoV = int.Parse(Console.ReadLine());
                Genero[i] = generoV;

                Console.WriteLine("¿El maestr@ cuenta con maestria? 1.SI 2.No");
                maestriaV = int.Parse(Console.ReadLine());
                Maestria[i] = maestriaV;

                Console.Clear();
            }




        }

        public void ImprimirArreglos()
        {
            Console.WriteLine("Datos de los maestros: ");
            
            for (int i = 0; i < Nombres.Length; i++)
            {
                Console.Write("Nombre:  " + Nombres[i] + " ");

                Console.Write("Edad: " + Edad[i] + " ");

                Console.Write("Genero: " + Genero[i] + " ");

                Console.Write("Mestrias: " + Maestria[i] + " ");

                Console.WriteLine("  ");
            }
          
        }

        public void PromEdad()
        {
            int cont = 0;
            double prom = 0;

            Console.WriteLine(" ");
            for (int i = 0; i < Edad.Length; i++)
            {
                prom = prom + Edad[i];
            }
            prom = prom / Edad.Length;

            Console.WriteLine("--------------------------------------------------------------");
            Console.WriteLine("El promedio de la edad es: " + prom);
            Console.WriteLine(" ");
            for (int i = 0; i < Edad.Length; i++)
            {
                
                if (Edad[i] < prom)
                {
                    cont++;
                }
            }
            Console.WriteLine("Existe: " + cont + " maestros con edad menor al promedio.");
            Console.WriteLine("---------------------------------------------------------------");
        }

        public void MenoryMayor()
        {

            int nommenor = 0;
            int nommayor = 0;

            double mayor = Edad[0], menor = Edad[0];

            for (int j = 0; j < Edad.Length; j++)
            {
                if (Edad[j] > mayor)
                {
                    mayor = Edad[j];
                    nommayor++;
                }
                if (Edad[j] < menor)
                {
                    menor = Edad[j];
                    nommenor++;
                }


            }
            Console.WriteLine("----------------------------------");
            Console.WriteLine("El maestro mas joven es: " + Nombres[nommenor] + " con edad: " + menor);
            Console.WriteLine("El maestro mas grande es: " + Nombres[nommayor] + " con edad: " + mayor);
            Console.WriteLine("----------------------------------");
        }

        public void HombresyMujeres()
        {
            int contM = 0;
            for (int i = 0; i < Genero.Length; i++)
            {
                if (Genero[i] == 2)
                {
                    contM++;
                }
            }
            Console.WriteLine("-------------------------------------------");
            Console.WriteLine("En el grupo hay: " + contM + " mujeres.");
            Console.WriteLine("--------------------------------------------");
        }

        public void Maestrias()
        {
            int contmaestrias = 0;
            for (int i = 0; i < Maestria.Length; i++)
            {
                if (Maestria[i] == 1)
                {
                    contmaestrias++;
                }
            }
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("En el grupo hay: " + contmaestrias + " maestr@ con maestrias.");
            Console.WriteLine("----------------------------------------------------------------");
        }

    }
}
