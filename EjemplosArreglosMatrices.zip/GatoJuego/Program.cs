﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GatoJuego
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Prueba p = new Prueba();
            Console.ReadKey();
        }
    }
}