﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArreglosEjemplo2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Alumno a = new Alumno();
            Console.ReadKey();

        }
    }
}
