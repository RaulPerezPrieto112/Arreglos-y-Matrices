﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ArreglosEjemplo2
{
    internal class Alumno
    {
        int x;
        double[] promedios;
        string[] nombres;
        


        public Alumno()
        {
            Console.Write("Cantidad de alumnos a capturar: ");
            x = int.Parse(Console.ReadLine());

            nombres= new string[x];
            promedios = new double[x];

            Capturar();
            Console.ReadKey();
            Console.Clear();
            Imprimir();
            Console.ReadKey();
            Console.Clear();
            reprobados();
            aprobados();
            menorymayorProm();

        }

        public void Capturar()
        {
            double c, prom;

            for (int i = 0; i < x; i++)
            {
                prom = 0;
                Console.Write("Captura el " +(i + 1) + " alumno: ");
                nombres[i] = Console.ReadLine();

                for (int j = 1; j <= 3; j++)
                {

                    Console.Write("introduce la calificacion " + j  + ": ");
                    c = double.Parse(Console.ReadLine());
                    prom = prom + c;
                }
                prom = prom / 3;
                promedios[i] = prom;

            }

           

        }

        public void Imprimir() 
        {

            for (int i = 0; i < nombres.Length; i++)
            {

                Console.WriteLine("Nombre: " + nombres[i] + "  Promedio: " + promedios[i]);
                

            }

        }

        public void reprobados()
        {
            
            Console.WriteLine("Los alumnos reprobados son.... ");

            for (int i = 0; i < nombres.Length; i++)
            {
                if (promedios[i] <= 7.9)
                {
                    Console.WriteLine( nombres[i] );
                }
                

            }

            
        }

        public void aprobados()
        {
            Console.WriteLine("Los alumnos aprobados son....... ");

            for (int i = 0; i < nombres.Length; i++)
            {
                if (promedios[i] >=8)
                {
                    Console.WriteLine( nombres[i] );
                }

            }
        }

        public void menorymayorProm()
        {

            double mayor = promedios[0], menor = promedios[0];

            for (int j = 0; j < promedios.Length; j++)
            {
                if (promedios[j] > mayor)
                {
                    mayor = promedios[j];

                }
                if (promedios[j] < menor)
                {
                    menor = promedios[j];
                }


            }
            Console.WriteLine("----------------------------------");
            Console.WriteLine("El promedio menor es: " + menor);
            Console.WriteLine("El promedio mayor es: " + mayor);
            Console.WriteLine("----------------------------------");
        }

    }
}
