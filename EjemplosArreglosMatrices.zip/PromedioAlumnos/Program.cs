﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromedioAlumnos
{
    internal class Program
    {
        static void Main(string[] args)
        {

            PromedioAlumnos A = new PromedioAlumnos();
            Console.ReadKey();

        }
    }
}
