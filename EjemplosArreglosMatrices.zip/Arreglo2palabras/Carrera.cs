﻿using System;

namespace Ejercicio2Arreglos
{
    public class Carrera
    {
        // DECLARACIÓN DE ARREGLOS
        string[] nombres;
        int[] edades;
        int[] generos;
        int[] maestrias;

        // DECLARACIÓN DE VARIABLES
        string nombre, joven;
        int edad, genero, maestria, n, contMenor, contMujeres, contMaestrias;
        double sumaProm, prom;

        public Carrera()
        {
            Console.WriteLine("Cantidad de maestros a introducir:");
            n = int.Parse(Console.ReadLine());

            // DEFINICIÓN DE ARREGLOS
            nombres = new string[n];
            edades = new int[n];
            generos = new int[n];
            maestrias = new int[n];

            entradaDatos();
            edadPromedio();
            profJoven();
            edadMenorPromedio();
            profMujeres();
            profMaestrias();
        }

        public void entradaDatos()
        {
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.Clear();
                Console.WriteLine("Universidad Tecnológica de Chihuahua");

                Console.WriteLine("Nombre:");
                nombre = Console.ReadLine();
                nombres[i] = nombre;

                Console.WriteLine("Edad:");
                edad = int.Parse(Console.ReadLine());
                edades[i] = edad;
                sumaProm += edades[i];

                Console.WriteLine("Género: \n1. Masculino \n2. Femenino");
                genero = int.Parse(Console.ReadLine());
                generos[i] = genero;

                Console.WriteLine("¿Cuenta con grado de maestría? \n1. Sí \n2. No");
                maestria = int.Parse(Console.ReadLine());
                maestrias[i] = maestria;
            }
        }

        public void edadPromedio()
        {
            for (int i = 0; i < edades.Length; i++)
            {
                prom = sumaProm / n;
            }
            Console.WriteLine("Promedio de las edades: " + prom);
        }

        public void profJoven()
        {
            for (int i = 0; i < edades.Length; i++)
            {
                if (edades[i] <= edades[0])
                    joven = nombres[i];
            }
            Console.WriteLine("El profesor más jóven es: " + joven);
        }

        public void edadMenorPromedio()
        {
            for (int i = 0; i < edades.Length; i++)
            {
                if (edades[i] < prom)
                {
                    contMenor++;
                }
            }
            Console.WriteLine("Hay " + contMenor + " profesores menores a la edad promedio");
        }

        public void profMujeres()
        {
            for (int i = 0; i < generos.Length; i++)
            {
                if (generos[i] == 2)
                {
                    contMujeres++;
                }
            }
            Console.WriteLine("Hay " + contMujeres + " profesoras mujeres");
        }

        public void profMaestrias()
        {
            for (int i = 0; i < maestrias.Length; i++)
            {
                if (maestrias[i] == 1)
                {
                    contMaestrias++;
                }
            }
            Console.WriteLine("Hay " + contMaestrias + " profesores que cuentan con maestría");
        }
    }
}