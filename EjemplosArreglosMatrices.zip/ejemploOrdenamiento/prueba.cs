﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejemploOrdenamiento
{
    internal class prueba
    {
        int i, j, k, n, aux;
        int[] v;

        public prueba()
        {
            ejemploOrdenamiento();
        }

        public void ejemploOrdenamiento()
        {
            Console.WriteLine("Ingresa la dimension del arreglo: ");
            n = int.Parse(Console.ReadLine());
            v = new int[n];

            Console.WriteLine("Ingresa los valores al arreglo:");
            for (int i = 1; i < v.Length; i++)
            {
                v[i - 1] = int.Parse(Console.ReadLine());
            }
            for (int i = 1; i < n-1; i++)
            {
                aux = v[i - 1];
                k = i;
                for (int j = 1; j < n-1; j++)
                {
                    if (v[j-1] < aux)
                    {
                        aux = v[j-1];
                        k= j;
                    }
                }
                v[k-1] = v[i-1];
                v[i-1] = aux;
            }

            for (int i = 1; i < v.Length; i++)
            {
                Console.Write(v[i-1] + " ");
            }
        }
    }
}
