﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace PromedioAlumnos
{
    internal class PromedioAlumnos
    {
        String nombre;
        int cal1, cal2, cal3, resp, contNA = 0,contSA = 0, contDE = 0, contAU = 0, contAlum = 0;
        double prom;
       
        public PromedioAlumnos()
        { 
            CapturaDeAlumnos();
        }

        public void CapturaDeAlumnos()
        {

            Console.Write("Introduce el nombre del usuario: ");
            nombre = Console.ReadLine();
            contAlum++;
            Console.WriteLine("introduce 3 calificaciones: ");
            cal1 = int.Parse(Console.ReadLine());
            cal2 = int.Parse(Console.ReadLine());
            cal3 = int.Parse(Console.ReadLine());

            PromedioFinalDelAlumno();

            Console.WriteLine("¿Deseas introducir otro usuario?. 1.SI, 2.NO");
            resp = int.Parse(Console.ReadLine());


            while (resp == 1)
            {
                Console.Clear();
                CapturaDeAlumnos();
               
            }

            Console.Clear();


            Resultados();


        }

        public void PromedioFinalDelAlumno()
        {

            Console.Clear();
            prom = (cal1 + cal2 + cal3)/ 3;

            if (prom < 8)
            {
                Console.WriteLine("Promedio reprobatorio (NA).");
                contNA++;
               
            }else if (prom >=8 && prom <8.5)
            {
                Console.WriteLine("Promedio satisfactorio (SA).");
                contSA++;
               
            }else if(prom <= 9 && prom >=8.5)
            {
                Console.WriteLine("Promedio Destacado (DE).");
                contDE++;
            }else if (prom >= 10)
            {
                Console.WriteLine("Promedio autonomo (AU).");
                contAU++;
            }

            Console.WriteLine("El alumno: " + nombre + " Tiene un promedio de: " + prom);


            
            
        }

        public void Resultados()
        {
            Console.WriteLine("Total de alumnos registrados: " + contAlum);
            Console.WriteLine("Total de alumnos con calificacion NA: " +contNA);
            Console.WriteLine("Total de alumnos con calificacion SA: " +contSA);
            Console.WriteLine("Total de alumnos con calificacion DE: " +contDE);
            Console.WriteLine("Total de alumnos con calificacion AU: " +contAU);
        }


    }
}
