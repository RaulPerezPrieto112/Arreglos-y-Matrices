﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen
{
    internal class prueba
    {
        string[] palabraBuscar;
        int resp;
        string[] buscarPalabra;
        string[] palabraEncontrada;
        string[] arregloVocales;
        string[,] matriz;
        int x, y, z;
        int cont = 0, contA = 0, contE = 0, contI = 0, contO = 0, contU = 0;
        public prueba()
        {
            llenar();
            vocales();
            imprimir();
            buscarP();
            buscarEnMatriz();
        }

        public void llenar()
        {
            Console.WriteLine("cuantas filas tendra tu matriz?");
            x = int.Parse(Console.ReadLine());
            y = x;
            matriz = new string[x, y];



            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    Console.WriteLine("Introduce la posicion: " + (f + 1) + "," + (c + 1));
                    matriz[f, c] = Console.ReadLine();

                }
            } 

            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("matriz llena:");
            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    Console.Write(matriz[f,c]);
                }
                Console.WriteLine(" ");
            }
        }

        public void vocales()
        {
            
            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    if (matriz[f, c] == "a")
                    {
                        cont++;
                        contA++;
                    }
                    else if (matriz[f, c] == "e")
                    {
                        cont++;
                        contE++;
                    }
                    else if (matriz[f, c] == "i")
                    {
                        cont++;
                        contI++;
                    }
                    else if (matriz[f, c] == "o")
                    {
                        cont++;
                        contO++;
                    }
                    else if (matriz[f, c] == "u")
                    {
                        cont++;
                        contU++;
                    }

                }
            }
            arregloVocales = new string[cont];

           
            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    for (int i = 0; i < arregloVocales.Length; i++)
                    {
                        if (matriz[f, c] == "a")
                        {
                            arregloVocales[i] = "a";
                        }
                        else if (matriz[f, c] == "e")
                        {
                            arregloVocales[i] = "e";
                        }
                        else if (matriz[f, c] == "i")
                        {
                            arregloVocales[i] = "i";
                        }
                        else if (matriz[f, c] == "o")
                        {
                            arregloVocales[i] = "o";
                        }
                        else if (matriz[f, c] == "u")
                        {
                            arregloVocales[i] = "u";
                        }
                    }
                }
            }
        }

        public void imprimir()
        {
            Console.Write(" ");
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Total de vocales encontradas: " + cont);
            Console.WriteLine("Total de letras ´A´ encontradas: " + contA);
            Console.WriteLine("Total de letras ´E´ encontradas: " + contE);
            Console.WriteLine("Total de letras ´I´ encontradas: " + contI);
            Console.WriteLine("Total de letras ´O´ encontradas: " + contO);
            Console.WriteLine("Total de letras ´U´ encontradas: " + contU);
            Console.WriteLine("-----------------------------------------------");

            Console.WriteLine("Arreglo de vocales: ");
            for (int i = 0; i < arregloVocales.Length; i++)
            {
                Console.Write(arregloVocales[i] + " ");
            }

        }

        public void buscarP()
        {
            Console.WriteLine(" ");
            Console.WriteLine("introduce la dimension de la palabra a buscar: ");
            resp = int.Parse(Console.ReadLine());
            palabraBuscar = new string[resp];
            palabraEncontrada = new string[resp];

            for (int i = 0; i < palabraBuscar.Length; i++)
            {
                Console.Write("Introduce la "+ (i + 1) + " letra: ");
                palabraBuscar[i] = Console.ReadLine();
                Console.WriteLine(" ");
            }

            Console.WriteLine("palabra a buscar: ");
            for (int i = 0; i < palabraBuscar.Length; i++)
            {
                Console.Write(palabraBuscar[i] + " ");
            }
        }

        public void buscarEnMatriz()
        {
            int contP = 0;
            Console.WriteLine(" ");
            for (int i = 0; i < palabraBuscar.Length; i++)
            {
                for (int f = 0; f < x; f++)
                {
                    for (int c = 0; c < y; c++)
                    {
                        if (palabraBuscar[i] == matriz[f, c])
                        {
                            palabraEncontrada[i] = palabraBuscar[i];
                            contP++;
                        }
                    }
                }
            }

            Console.WriteLine(" ");

            if (contP == resp)
            {
                Console.WriteLine("Palabra encontrada");
                for (int i = 0; i < palabraEncontrada.Length; i++)
                {
                    Console.Write(palabraEncontrada[i] + " ");
                }
            }
            else
            {
                Console.WriteLine("Palabra no encontrada");
            }


            
        }
    }
}
