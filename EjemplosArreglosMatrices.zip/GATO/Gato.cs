﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GATO
{
    internal class Gato
    {

        static char[] tablero = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        static int jugadorActual = 1;
        static int eleccion;
        public Gato() 
        {
            DibujarTablero();
            VerificarGanador();
        }

        public void DibujarTablero()
        {
            Console.WriteLine("     |     |      ");
            Console.WriteLine("  {0}  |  {1}  |  {2}", tablero[0], tablero[1], tablero[2]);
            Console.WriteLine("_____|_____|_____ ");
            Console.WriteLine("     |     |      ");
            Console.WriteLine("  {0}  |  {1}  |  {2}", tablero[3], tablero[4], tablero[5]);
            Console.WriteLine("_____|_____|_____ ");
            Console.WriteLine("     |     |      ");
            Console.WriteLine("  {0}  |  {1}  |  {2}", tablero[6], tablero[7], tablero[8]);
            Console.WriteLine("     |     |      ");
        }

        static int VerificarGanador()
        {
            //Filas horizontales
            if (tablero[0] == tablero[1] && tablero[1] == tablero[2])
                return 1;
            else if (tablero[3] == tablero[4] && tablero[4] == tablero[5])
                return 1;
            else if (tablero[6] == tablero[7] && tablero[7] == tablero[8])
                return 1;

            //Filas verticales
            else if (tablero[0] == tablero[3] && tablero[3] == tablero[6])
                return 1;
            else if (tablero[1] == tablero[4] && tablero[4] == tablero[7])
                return 1;
            else if (tablero[2] == tablero[5] && tablero[5] == tablero[8])
                return 1;

            //Diagonales
            else if (tablero[0] == tablero[4] && tablero[4] == tablero[8])
                return 1;
            else if (tablero[2] == tablero[4] && tablero[4] == tablero[6])
                return 1;
            else if (Array.IndexOf(tablero, '1', 0, 9) == -1)
                return -1;
            else
                return 0;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Juego del Gato en C#");
            Console.WriteLine("Jugador 1 (X)  - Jugador 2 (O)\n");
            Console.WriteLine("Presiona una tecla para comenzar el juego\n");
            Console.ReadKey();
            Console.Clear();

            
        }

    }
}
