﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Ala
    {
        public Ala() 
        {
            ahorcado();
        }

        public void ahorcado()
        {
            string[] palabra = null;
            int vidas = 5;
            string respuesta = "";

            Console.WriteLine("Jugador 1, ingrese la longitud de la palabra a adivinar:");
            int longitud = int.Parse(Console.ReadLine());

            palabra = new string[longitud];

            Console.WriteLine("Jugador 1, ingrese las letras de la palabra separadas por espacio:");
            for (int i = 0; i < longitud; i++)
            {
                palabra[i] = Console.ReadLine();
            }

            Console.Clear();

            Console.WriteLine("Jugador 2, es tu turno para adivinar la palabra.");

            for (int i = 0; i < longitud; i++)
            {
                Console.Write("_ ");
            }

            Console.WriteLine();

            while (vidas > 0)
            {
                Console.WriteLine("Ingrese una letra:");
                string letra = Console.ReadLine();
                bool encontrado = false;

                for (int i = 0; i < longitud; i++)
                {
                    if (letra == palabra[i])
                    {
                        Console.Write(letra + " ");
                        encontrado = true;
                    }
                    else
                    {
                        Console.Write("_ ");
                    }
                }

                Console.WriteLine();

                if (!encontrado)
                {
                    vidas--;
                    Console.WriteLine("La letra no se encuentra en la palabra. Te quedan " + vidas + " vidas.");
                    Console.WriteLine(" _________");
                    Console.WriteLine(" |         |");
                    Console.WriteLine(" |         O");
                    Console.WriteLine(" |        /|\\");
                    Console.WriteLine(" |        / \\");
                    Console.WriteLine("_|_");
                }

                if (vidas == 0)
                {
                    Console.WriteLine("Has perdido. La palabra era: ");
                    for (int i = 0; i < longitud; i++)
                    {
                        Console.Write(palabra[i] + " ");
                    }
                    Console.WriteLine();
                    break;
                }

                Console.WriteLine("Quieres adivinar la palabra completa? (s/n)");
                respuesta = Console.ReadLine();

                if (respuesta == "s")
                {
                    Console.WriteLine("Ingrese la palabra completa:");
                    string palabraCompleta = Console.ReadLine();
                    string palabraOriginal = "";

                    for (int i = 0; i < longitud; i++)
                    {
                        palabraOriginal += palabra[i];
                    }

                }
            }
        }
    }
}
