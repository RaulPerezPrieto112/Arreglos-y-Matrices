﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumerosPrimosEnUnRango
{

    internal class Prueba
    {

        int numero;
        int contador = 0;

        public Prueba()
        {
            Console.WriteLine("Intoduce un numero: ");
            numero = int.Parse(Console.ReadLine());

            ImprimirPrimo();
        }

        public void ImprimirPrimo()
        {

            for (int num2 = 1; num2 <= numero; num2++)
            {

                if (numero % num2 == 0)
                {
                    contador++;
                }
                
            }

            if (contador == 2)
            {

                Console.WriteLine("El numero es primo");

            }
            else
            {
                Console.WriteLine("El numero no es primo");
            }
        }

    }      
    
}
