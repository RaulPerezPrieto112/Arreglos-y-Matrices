﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace resursividad4
{
    internal class prueba
    {
        string cadena;
        int contp = 0;
        public prueba()
        {

            Console.WriteLine("Introduce la oracion: ");
            cadena = Console.ReadLine();
            Console.WriteLine("La oracion es: " + cadena);
            contarpalabras(0);

        }

        public void contarpalabras(int p)
        {
            char x = ' ';
            int cont = 0;
            char l;
            contp++;
            for (int i = p; i < cadena.Length; i++)
            {
                l = (cadena[p]);
                if (l != x)
                {
                    cont++;
                    Console.Write(l);
                    p++;
                    
                }
                else
                {
                    p++;
                    break;
                }
            }
            Console.Write("   : Cantidad de letras: " + cont);
            Console.WriteLine(" ");
            if (p < cadena.Length)
            {
                contarpalabras(p);
            }

        }

    }
}
