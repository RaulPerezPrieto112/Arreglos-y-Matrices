﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matrices2
{
    internal class matriz
    {

        int[,] numeros;
        int x, y;
        int[] horizontal1;
        int[] horizontal2;
        double prom;
        public matriz() 
        {
            TamañoMatriz();
            Console.Clear();
            llenar();
            Console.Clear();
            imprimir();
            Encontrar1();
            ImpDiagonal1();
            Menores();



        }

        public void TamañoMatriz()
        {
            Console.WriteLine("Introduce la cantidad de filas  y columnas: ");
            x = int.Parse(Console.ReadLine());

            y = x;

            numeros = new int[x, y];
            horizontal1 = new int[x];
            horizontal2 = new int[x];

        }

        public void llenar()
        {
            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {

                    Console.WriteLine("introduce la posicion: [ " + (f + 1) + " , " + (c + 1) + " ]");
                    numeros[f, c] = int.Parse(Console.ReadLine());

                }
                Console.Clear();
            }
            Console.ReadKey();
            Console.Clear();
        }

        public void imprimir()
        {

            Console.WriteLine("Matriz llena");

            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {

                    Console.Write(numeros[f, c] + " ");

                }
                Console.WriteLine("");
            }

        }

        public void Encontrar1()
        {
          
            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < x; c++)
                {
                    if (f == c)
                    {
                        horizontal1[c] = numeros[f, c];
                    }
                    if ((f + c) == (x - 1))
                    {
                        horizontal2[c] = numeros[f, c];
                    }
                }
                
            }

        }

        public void ImpDiagonal1()
        {
           
            int num = 0;
            int num2 = 0; Console.WriteLine("------------------------------------");
            Console.WriteLine("Primer diagonal: ");
            for (int i = 0; i < horizontal1.Length; i++)
            {
                Console.Write(horizontal1[i] + " ");
                num = num + horizontal1[i];
            }

            Console.WriteLine("");
            Console.WriteLine("Segunda diagonal: ");
            for (int j = 0; j < horizontal2.Length; j++)
            {
                Console.Write(horizontal2[j] + " ");
                num2 = num2 + horizontal2[j];
            }

            prom = (num + num2) / (x + x);
            Console.WriteLine(" ");

            Console.WriteLine("El promedio de la diagonal es: " + prom);


        }

        public void Menores()
        {
            int cont1 = 0;

            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    if (numeros[f,c] < prom)
                    {
                        cont1++;
                    }
                }
               
            }
            Console.WriteLine("El numero de numeros menores al promedio son: " + cont1);
            Console.WriteLine("------------------------------------");
        }

        

    }
}
