﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace recursividad1
{
    internal class prueba
    {

        int x;
        public prueba() 
        {

            Console.WriteLine("Introduce la cantidad de veces a contar");
            x = int.Parse(Console.ReadLine());

            contar(0);
        }

        public void contar(int n)
        {
            Console.WriteLine(n);
            n++;
            if (n <= x)
            {
                contar(n);
            }
            else
            {
                Console.WriteLine("Programa terminado.");
            }
            
        }

    }
}
