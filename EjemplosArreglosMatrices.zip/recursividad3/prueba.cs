﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace recursividad3
{
    internal class prueba
    {
        int x, cont = 1;
        public prueba()
        {
            Console.WriteLine("Introduce el numero factorial: ");
            x = int.Parse(Console.ReadLine());
            imprimirfactorial(1);
        }

        public void imprimirfactorial(int f)
        {
            Console.Write(f);
            cont = cont * f;
            f++;
            if (f <= x)
            {
                Console.Write("*");
                imprimirfactorial(f);
            }
            else
            {
                Console.Write("=");
                Console.Write(cont);
            }
        }

    }
}
