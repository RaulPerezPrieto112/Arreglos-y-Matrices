﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace calificaciones
{
    internal class calificar
    {
        string[] materias = {"Alumno", "Español", "Matematicas", "Historia", "Ingles", "Promedio alumno"};
        string[] alumnos;
        int[,] calificaciones;
        double[] promedioAlumno;
        double[] promedioMateria;
        int x;
        double prom, prom2;
        double promGeneral;
        

        public calificar()
        {
            materiasllenar();
            Console.Clear();
            imprimir();
            imprimir2();
            imprimir3();
            promBajo();
        }

        public void materiasllenar()
        {
            string alumno;

            Console.WriteLine("Cuantos alumnos tiene: ");
            x = int.Parse(Console.ReadLine());
            alumnos = new string[x];
            calificaciones = new int[x, 4];
            promedioAlumno = new double[x];
            promedioMateria = new double[x];


            for (int c = 0; c < x; c++)
            {
                Console.WriteLine("Ingresa el: " + (c + 1) + " alumno: ");
                alumno = Console.ReadLine();
                alumnos[c] = alumno;

                for (int f = 0; f < 4; f++)
                {
                    Console.WriteLine("Introduce la  " + (f + 1) + " Calificacion");
                    calificaciones[c, f] = int.Parse(Console.ReadLine());
                }

                Console.Clear();
            }
        }

        public void imprimir()
        {
            int cal = 0, cal2 = 0;
            int cont = 0;

            Console.WriteLine("Calificaciones: ");
            for (int i = 0; i < materias.Length; i++)
            {
                Console.Write(materias[i] + " ");
            }

            Console.WriteLine(" ");
            for (int c = 0; c < x; c++)
            {
                cal = 0;
                cal2 = 0;
                Console.Write(alumnos[c] + "    ");
                for (int f = 0; f < 4; f++)
                {
                    Console.Write(calificaciones[c, f] + "         ");
                    cal = cal + calificaciones[c, f];
                }
                prom = cal / 4;
                promedioAlumno[c] = prom;
                Console.Write(promedioAlumno[c]);
                Console.WriteLine(" ");

            }

        }

        public void imprimir2()
        {
            double califG = 0;
            int cont;
            double prom2 = 0;
            double calif1 = 0;
            Console.Write("Prom:   ");
            for (int c = 0; c < 4; c++)
            {
                cont = 0;
                for (int f = 0; f < x; f++)
                {
                    calif1 = calif1 + calificaciones[f, c];
                    
                }
                prom2 = calif1 / x;
                promedioMateria[cont] = prom2;
                calif1 = 0;
                Console.Write(promedioMateria[cont] + "        ");
                cont++;
            }
            for (int i = 0; i < promedioAlumno.Length; i++)
            {
                califG = califG + promedioAlumno[i];
            }
            promGeneral = califG/ x;
            Console.Write(promGeneral);
            
        }

        public void imprimir3() 
        {
            double mayor = promedioMateria[0], menor = promedioMateria[0];
            int cont2 = 0, cont3 = 0;
            Console.WriteLine(" ");
            
            for (int j = 0; j < promedioMateria.Length; j++)
            {
                if (promedioMateria[j] > mayor)
                {
                    mayor = promedioMateria[j];

                    cont2++;
                }
                if (promedioMateria[j] < menor)
                {
                    menor = promedioMateria[j];

                    cont3++;
                }
            }
            Console.WriteLine("----------------------------------");
            Console.WriteLine("La materia mas alta fue " + materias[cont3 + 1 +1]);
            Console.WriteLine("La materia mas baja fue " + materias[cont2 + 1]);
            Console.WriteLine("----------------------------------");
        }

        public void promBajo()
        {
            double mayor = promedioAlumno[0], menor = promedioAlumno[0];
            int cont2 = 0, cont3 = 0;
            Console.WriteLine(" ");

            for (int j = 0; j < promedioAlumno.Length; j++)
            {
                if (promedioAlumno[j] > mayor)
                {
                    mayor = promedioAlumno[j];

                    cont2++;
                }
                if (promedioAlumno[j] < menor)
                {
                    menor = promedioAlumno[j];

                    cont3++;
                }
            }
            Console.WriteLine("----------------------------------");
            Console.WriteLine("El promedio mas bajo fue " + alumnos[cont3]);
            Console.WriteLine("El promeido mas alto fue " + alumnos[cont2]);
            Console.WriteLine("----------------------------------");
        }

    }
}
