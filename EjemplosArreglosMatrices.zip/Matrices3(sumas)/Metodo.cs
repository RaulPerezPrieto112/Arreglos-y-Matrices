﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matrices3_sumas_
{
    internal class Metodo
    {
        int x, y;
        
        int[,] numeros;
        int[] FilaSumada;
        public Metodo()
        {
            TamañoMatriz();
            Console.Clear();
            llenar();
            imprimir();
            SumaFilas();
            EncontrarPrimo();
        }

        public void TamañoMatriz()
        {
            Console.WriteLine("Introduce la cantidad de filas: ");
            x = int.Parse(Console.ReadLine());
            Console.WriteLine("Introduce la cantidad de columnas: ");
            y = int.Parse(Console.ReadLine());

            numeros = new int[x, y];
            FilaSumada = new int[x];
         

        }

        public void llenar()
        {
            int sum = 0;

            for (int f = 0 ; f < x; f++)

            {
                for (int c = 0 ; c < y; c++)
                {
                    try
                    {
                        Console.WriteLine("introduce el numero en la posicion: [ " + (f + 1) + " , " + (c + 1) + " ]");
                        numeros[f, c] = int.Parse(Console.ReadLine());
                        sum = sum + numeros[f, c];
                    }
                    catch
                    {
                        Console.WriteLine("Introduce solo numeros.");
                        c--;
                    }
                }
                Console.Clear();
                FilaSumada[f] = sum;
                sum = 0;
            }
        }

        public void imprimir()
        {

            Console.WriteLine("Matriz llena");

            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {

                    Console.Write(numeros[f, c] + " ");

                }
                Console.WriteLine("");
            }

        }

        public void SumaFilas()
        {
            int cont1 = 0, cont2 = 1, cont3 = 1 ;
            int nommenor = 0;
            int nommayor = 0;
            double mayor = FilaSumada[0], menor = FilaSumada[0];

            Console.WriteLine("Arreglo con sumas: ");
            for (int i = 0; i < FilaSumada.Length; i++)
            {
                cont1++;
                Console.Write("Suma de la fila " + cont1 + ": ");
                Console.Write(FilaSumada[i] + " ");
                Console.WriteLine(" ");
            }

            Console.WriteLine(" ");
            for (int j = 0; j < FilaSumada.Length; j++)
            {
                if (FilaSumada[j] > mayor)
                {
                    mayor = FilaSumada[j];
                    
                    cont2++; 
                }
                if (FilaSumada[j] < menor)
                {
                    menor = FilaSumada[j];
          
                    cont3++;
                }
            }
            Console.WriteLine("----------------------------------");
            Console.WriteLine("La fila con menor sumatoria es la " + cont3 + " Con un total de: " + menor);
            Console.WriteLine("La fila con mayor sumatoria es la " + cont2 + " Con un total de: " + mayor);
            Console.WriteLine("----------------------------------");

        }

        public void EncontrarPrimo()
        {
            Console.WriteLine("Numeros primos encontrados: ");

            int Contprim = 0;

            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    int l = numeros[f, c];
                    int count = 0;
                    for (int k = 1; k <= l; k++)
                    {
                        if (l % k == 0)
                        {
                            count++;
                        }
                    }
                    if (count == 2)
                    {
                        Contprim++;
                        Console.Write(l + " ");
                        count++;
                    }
                }   
            }

            Console.WriteLine(" ");
            Console.WriteLine("total de primos encontrados:" + Contprim);
        }

    }
}
