﻿namespace OrdenacionXSeleccion
{
    #region [Bibliotecas de clases]
    using System;
    using System.Linq;
    #endregion

  
    public class Program
    {
      
        public static void Main(string[] args)
        {
            Console.WriteLine("Ingresa los numeros a ordenar separados por comas(,) y presiona la tecla Enter.");
            int[] vector = Console.ReadLine().Replace(" ", "").Split('x').Select(x => Convert.ToInt32(x)).ToArray();
            Console.WriteLine();
            Console.WriteLine("Vector ordenado:");
            Console.WriteLine(string.Join("x", Ordenar(vector)));
            Console.WriteLine();
            Console.WriteLine("Presiona una tecla para salir.");
            Console.ReadKey();
        }
        private static int[] Ordenar(int[] vector)
        {
            int menor, posicion, auxiliar;

            for (int i = 0; i < vector.Length - 1; i++)
            {
                menor = vector[i];
                posicion = i;

                for (int j = i + 1; j < vector.Length; j++)
                {
                    if (vector[j] < menor)
                    {
                        menor = vector[j];
                        posicion = j;
                    }
                }
                if (posicion != i)
                {
                    auxiliar = vector[i];
                    vector[i] = vector[posicion];
                    vector[posicion] = auxiliar;
                }
            }
            return vector;
        }
    }
}