﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace BuscarPalabras
{
    internal class Palabras
    {
        string[] Letras = new string[10];
        string[] Cantidadletras;
        string[] encontrada;
        int contPalEnc;
        bool bandera = false;
        public Palabras()
        {
            RellenarLetras();
            Console.ReadKey();
            Console.Clear();
            PedirPalabra();
            ImprimirNomEnc();
        }


        public void RellenarLetras()
        {
            for (int i = 0; i < Letras.Length; i++)
            {

                Console.WriteLine("Introduce la: " + (i + 1) + " letra");
                Letras[i] = Console.ReadLine();

            }

            Console.WriteLine("Arreglo de letras: ");
            for (int i = 0; i < Letras.Length; i++)
            {
                Console.Write(" " + Letras[i]);
            }
           

        }

        public void PedirPalabra()
        {
            int resp = 0;

            do
            {

                Console.WriteLine(" ");
                int x;
                Console.Write("Introduce la cantidad de letras que tiene la palabra a buscar:");
                x = int.Parse(Console.ReadLine());
                Cantidadletras = new string[x];
                encontrada = new string[x];

                for (int i = 0; i < Cantidadletras.Length; i++)
                {
                    Console.Write("Introduce la " + (i + 1) + " letra de la palabra: ");
                    Cantidadletras[i] = Console.ReadLine();
                }

                Console.Write("Palabra a buscar: ");
                for (int j = 0; j < Cantidadletras.Length; j++)
                {
                    Console.Write("  " + Cantidadletras[j]);
                }
                Console.WriteLine(" ");
                Console.ReadKey();

                Console.Clear();
                Encontrarpalabra();

                Console.WriteLine("Desea buscar otra palabra?: 1.SI otro para no");
                resp = int.Parse(Console.ReadLine());

                Console.ReadKey();
                Console.Clear();

            }while(resp ==1);

        }

        public void Encontrarpalabra()
        {

            Console.WriteLine("Arreglo de letras: ");
            for (int i = 0; i < Letras.Length; i++)
            {
                Console.Write(" " + Letras[i]);
            }
            Console.WriteLine(" ");


            Console.WriteLine("Palabra a buscar: ");
            for (int j = 0; j < Cantidadletras.Length; j++)
            {
                Console.Write(" " + Cantidadletras[j]);
            }
            Console.WriteLine(" ");
            Console.WriteLine(" ");




            for (int k = 0; k < Cantidadletras.Length; k++)
            {

                for (int i = 0; i < 10; i++)
                {
                    if (Letras[i] == Cantidadletras[k])
                    {
                        bandera = true;

                    }
                    if (bandera == true)
                    {
                        encontrada[k] = Letras[i];
                    }
                    bandera = false;

                }

            }

            if (encontrada.Length != Letras.Length)
            {
                contPalEnc++;
                Console.WriteLine(" Se ha encontrado la palabra :D");
                Console.WriteLine(" ");
                for (int i = 0; i < encontrada.Length; i++)
                {
                    Console.Write(" " + encontrada[i]);

                }
            }
            else
            {
                Console.WriteLine("Palabra no encontrada");
            }
            
        }

        public void ImprimirNomEnc()
        {

                Console.WriteLine("Palabras encontradas: " + contPalEnc);
            
        }

    }

}
