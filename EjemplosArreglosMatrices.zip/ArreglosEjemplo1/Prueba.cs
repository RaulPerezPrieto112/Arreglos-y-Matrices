﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArreglosEjemplo1
{
    internal class Prueba
    {

        int x, y;
        int[] numeros; // declarar entero de numeros
        string[] nombres; // declarar arreglo de cadenas

        public Prueba()
        {

            Console.WriteLine("Introduce la dimension del arreglo de numeros");
            x = int.Parse(Console.ReadLine());
            Console.WriteLine("Introduce la dimension del arreglo de cadenas");
            y = int.Parse(Console.ReadLine());
            
            numeros = new int[x];   // definiendo el numero de datos que tendra el arreglo de numeros
            nombres = new string[y]; // definiendo el numero de datos que tendra el arreglo de cadenas
            
            Llenar();
            Console.ReadKey();
            Console.Clear();
            Imprimir();
            ordenar();
            Console.ReadKey();
            Console.Clear();
            Imprimir();
            VoltearArreglo();
            Console.ReadKey();
            Console.Clear();
            Imprimir();

        }

        public void Llenar()
        {

            for (int i = 0; i < x; i++) //arreglo para llenar numeros :D
            {

                Console.WriteLine("Introduce el " + (i + 1) + " numero: ");
                numeros[i] = int.Parse(Console.ReadLine());

            }

            for (int j = 0; j < nombres.Length; j++) //arreglo para llenar numeros
            {

                Console.Write("introduce el " + (j + 1) + "nombre: ");
                nombres[j] = Console.ReadLine();

            }

        }

        public void Imprimir()
        {
            Console.WriteLine("Arreglo de numeros");
            for (int i = 0; i < numeros.Length; i++)
            {
                Console.Write(numeros[i] + "  ");
                
            }
            Console.WriteLine(" ");
            Console.WriteLine("Arreglo de nombres");

            for (int j = 0; j < nombres.Length; j++)
            {
                Console.Write(nombres[j] + "  ");

            }
        }

        public void ordenar()
        {
            Console.WriteLine("");
            Console.WriteLine("Ordenando arrreglos......");
            Array.Sort(numeros);
            Array.Sort(nombres);

        }

        public void VoltearArreglo()
        {
            Console.WriteLine("  ");
            Console.WriteLine("volteando arreglos.....");
            Array.Reverse(numeros);
            Array.Reverse(nombres);
        }

    }
}
