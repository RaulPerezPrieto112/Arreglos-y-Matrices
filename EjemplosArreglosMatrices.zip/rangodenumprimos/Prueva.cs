﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace rangodenumprimos
{
    internal class Prueba
    {
        int r1, r2;
        int cont = 0, cont2 =0;
        public Prueba()
        {
            Console.WriteLine("Introduce un rango de numeros");
            r1=int.Parse(Console.ReadLine());
            r2=int.Parse(Console.ReadLine());

            Verificar();
            SeleccionarPrimos();

        }

        public void Verificar()
        {
            int aux = 0;

            if (r1>r2)
            {
                aux = r1;
                r1 = r2;   
                r2 = aux;
            }

        }

        public void SeleccionarPrimos()
        {
            for (int i =1;i <= r2; i++) //Sirve para correr el rango de numeros 
            {

                for (int j = 1; j <= i; j++)
                {
                    if (i % j == 0)
                    {
                        cont++;
                    }

                }

                if (cont == 2)
                {
                    Console.WriteLine("El numero: " +i+ " Es primo");
                    cont2++;
                }

                cont = 0;

            }

            Console.WriteLine("En tu rango existen: " + cont2 + " Numeros primos.");
        }

    }
}
