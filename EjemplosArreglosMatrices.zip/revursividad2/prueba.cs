﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace revursividad2
{
    internal class prueba
    {

        int t;

        public prueba()
        {

            Console.Write("Tabla de multiplicar: ");
            t = int.Parse(Console.ReadLine());
            imprimirtabla(1);
        }

        public void imprimirtabla(int c)
        {
            Console.WriteLine(c + "x" + t + " = " + (c * t));
            c++;
            if (c <= 10)
            {
                imprimirtabla(c);
            }
            else
            {
                Console.WriteLine("Programa finalizado.");
            }

        }

    }
}
