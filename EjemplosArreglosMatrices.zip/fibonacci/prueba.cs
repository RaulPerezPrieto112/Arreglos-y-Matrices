﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace fibonacci
{
    internal class prueba
    {
        int x, acu = 0, acu2 = 0;
        int t = 1;

        public prueba()
        {
            Console.WriteLine("Cantidad de elementos a imprimir: ");
            x = int.Parse(Console.ReadLine());
            imprimirfibonacci(1);
        }
        

        public void imprimirfibonacci(int n)
        {
            Console.Write(acu);
            acu2 = acu + t;
            t = acu;
            acu = acu2;
            n++;
            if (n <= x)
            { 
                Console.Write(" ");
                imprimirfibonacci(n);
            }
        }
    }
}
