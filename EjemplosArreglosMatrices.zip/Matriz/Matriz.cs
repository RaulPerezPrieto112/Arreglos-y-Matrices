﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matriz
{
    internal class Matriz
    {
        int x, y;
        int[,] numeros;
        public Matriz() 
        {
            Console.WriteLine("Introduce la cantidad de filas: ");
            x = int.Parse(Console.ReadLine());

            Console.WriteLine("Introduce la cantidad de columnas: ");
            y = int.Parse(Console.ReadLine());

            numeros = new int[x, y];

            Console.Clear();

            Llenar();
            imprimir();
            encontrarnumero();
        }

        public void Llenar()
        {
            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {

                    Console.WriteLine("introduce la posicion: [ " + (f+1) + " , " + (c + 1) + " ]");
                    numeros[f,c] = int.Parse(Console.ReadLine());           
                    
                }
                Console.Clear();
            }
            Console.ReadKey();
            Console.Clear();
        }

        public void imprimir()
        {

            Console.WriteLine("Matriz llena");

            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {

                    Console.Write(numeros[f,c] + " ");

                }
                Console.WriteLine("");
            }

        }

        public void encontrarnumero()
        {
            int buscar;
            int cont = 0;
            int cont2 = 0;
            int columna = 0;
            int repetidos = 0;
       

            Console.WriteLine("Introduce un numero a buscar: ");
            buscar = int.Parse(Console.ReadLine());

            for (int f = 0; f < x; f++)
            {
                for (int c = 0; c < y; c++)
                {
                    if (buscar == numeros[f,c])
                    {
                        columna++;
                        cont2++;
                        if (cont2 == 1)
                        {
                            Console.WriteLine("----------------------------------------------");
                            Console.WriteLine("El numero: " + buscar + " ha sido encontrado.");
                            Console.WriteLine("----------------------------------------------");
                        }


                        Console.WriteLine("Numero encontrado en la posicion: [" + (f + 1) + " , " + (c + 1) + " ]");
                        cont++;
                        repetidos = repetidos + numeros[f,c];
                       
                    }
                  

                }
            }

            Console.WriteLine(" ");
            Console.WriteLine("-------------------------------------------------------------------------");
            Console.WriteLine("El numero: "+ buscar + " se encuentra " + cont + " veces en la matriz");
            Console.WriteLine("La suma de los numeros repetidos es: " + repetidos);
            Console.WriteLine("-------------------------------------------------------------------------");
        }



    }
}
