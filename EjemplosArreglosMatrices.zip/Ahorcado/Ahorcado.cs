﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ahorcado
{
    internal class Ahorcado
    {
        string[] palabra;
        string[] buscador;
        string[] lineas;
        int intentos = 5;
        int x;
        int cont, cont2 = 0;
        public Ahorcado() 
        {

            Jugador1();
            Console.ReadKey();
            Console.Clear();
            Jugador2();
            Console.ReadKey();
            Console.Clear();
            Resultado();
            

        }

        public void Jugador1()
        {
            Console.WriteLine("Introduce el tamaño de la palabra que se debera buscar: ");
            x = int.Parse(Console.ReadLine());
            palabra = new string[x];
            buscador = new string[x];
            lineas = new string[x];
            
            

            Console.WriteLine("Introduce letra por letra por letra tu palabra: ");
            for (int i = 0; i < palabra.Length; i++)
            {
                Console.Write("Introduce la " + (i + 1) + " letra: ");
                palabra[i] = Console.ReadLine();
            }
            

        }

        public void Jugador2()
        {
            bool bandera = true;
            string y;
            int intentos2 = 0;
            
            Console.WriteLine("Juego iniciado, suerte :D");
            for (int j = 0; j < palabra.Length; j++)
            {
                Console.Write('-');
            }

            while(intentos > 0)
            {
                Console.WriteLine(" ");
                Console.Write("Introduce una letra a buscar: ");
                y = Console.ReadLine();

                cont = 0;
                for (int i = 0; i < palabra.Length; i++)
                {
                    bandera = false;
                    Console.WriteLine(" ");
                    Console.WriteLine("Intentos: " + intentos);
                    if (y == palabra[i])
                    {
                        cont++;
                        Console.WriteLine("letra encontrada :D");
                        bandera = true;

                        if (bandera = true)
                        {
                            for (int j = 0; j < palabra.Length; j++)
                            {
                                if (y == palabra[j])
                                {
                                    buscador[j] = palabra[j];
                                }
                            }
                        }
                        
                    }

                    if(bandera == false)
                    {
                        Console.WriteLine("Letra no encontrada :C");
                       
                        intentos--;
                        bandera = true;
                        
                    }
                    for (int j = 0; j < buscador.Length; j++)
                    {
                        if (buscador[j] != palabra[j])
                        {
                            Console.Write("- ");
                        }
                        else
                        {
                            Console.Write(" " + buscador[j]);
                        }
                    }

                   
                }
            }

        }

        public void Resultado()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Tu resultado es....");
            if (intentos == 0)
            {
                Console.WriteLine("perdiste, faltaron" + cont2 + " letras por encontrar");
            }
            if (intentos != 0) 
            {
                Console.WriteLine("Has ganado, encontraste las " + x + " letras");
            }
        }

    }


}
