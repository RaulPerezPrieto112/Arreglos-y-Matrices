﻿using System;

namespace Ejercicio2Arreglos
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Carrera c = new Carrera();
            Console.WriteLine("Pulse cualquier tecla para finalizar...");
            Console.ReadKey();
        }
    }
}
