﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumerosPrimosEnUnRango
{
    internal class Rango
    {

        int numero;
        int numero2;

        public Rango()
        {
            Console.Write("Intoduce el primer numero: ");
            numero = int.Parse(Console.ReadLine());
            Console.Write("Intoduce el segundo numero: ");
            numero2 = int.Parse(Console.ReadLine());
            ImprimirPrimo();
        }

        public void ImprimirPrimo()
        {

            Console.WriteLine("Tu rango es del: " + numero + " al " + numero2);


            for (int cont = numero; cont <= numero2; cont++)
            {
                int count = 0;

                for (int cont2 = 2; cont2 <= cont / 2; cont2++)
                {
                    if (cont % cont2 == 0)
                    {
                        count++;
                    }
                }

                if (count == 0 && cont != 2)
                {
                    Console.WriteLine(cont);
                }
            }
          

            Console.WriteLine("Programa finalizado");
        }

        


    }
}


